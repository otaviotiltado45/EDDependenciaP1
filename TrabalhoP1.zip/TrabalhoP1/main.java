public class main {
    public static void main(String[] args) {
        labirinto labirinto = new labirinto(); // Criando o labirinto manualmente

        System.out.println("Labirinto inicial:");
        labirinto.imprimirLabirinto();
        labirinto.resolverLabirinto();
    }
}
