import java.util.Stack;

public class labirinto {
    private char[][] labirinto;
    private int linhas;
    private int colunas;
    private int startX;
    private int startY;
    private int destinoX;
    private int destinoY;
    private Stack<int[]> pilha;
    private boolean[][] visitado;

    public labirinto() {
        // Definindo manualmente o labirinto de exemplo
        linhas = 7;
        colunas = 7;
        labirinto = new char[][] {
            {'1', '1', '1', '1', '1', '1', '1'},
            {'1', 'S', '0', '1', '0', '0', '1'},
            {'1', '1', '0', '1', '0', '1', '1'},
            {'1', '0', '0', '0', '0', '0', '1'},
            {'1', '0', '1', '1', '1', '0', '1'},
            {'1', '0', '0', 'D', '0', '0', '1'},
            {'1', '1', '1', '1', '1', '1', '1'}
        };
        pilha = new Stack<>();
        visitado = new boolean[linhas][colunas];

        // Encontra a posição inicial (S) e a posição do destino (D)
        encontrarPosicoesIniciais();
    }

    private void encontrarPosicoesIniciais() {
        for (int i = 0; i < linhas; i++) {
            for (int j = 0; j < colunas; j++) {
                if (labirinto[i][j] == 'S') {
                    startX = i;
                    startY = j;
                } else if (labirinto[i][j] == 'D') {
                    destinoX = i;
                    destinoY = j;
                }
            }
        }
    }

    public void imprimirLabirinto() {
        for (int i = 0; i < linhas; i++) {
            for (int j = 0; j < colunas; j++) {
                System.out.print(labirinto[i][j] + " ");
            }
            System.out.println();
        }
    }

    public void resolverLabirinto() {
        if (encontrarCaminho(startX, startY)) {
            System.out.println("Caminho encontrado até o destino (D):");
            imprimirCaminho();
        } else {
            System.out.println("Não foi possível encontrar um caminho até o destino.");
        }
    }

    private boolean encontrarCaminho(int x, int y) {
        if (x < 0 || x >= linhas || y < 0 || y >= colunas || labirinto[x][y] == '1' || visitado[x][y]) {
            return false;
        }

        pilha.push(new int[]{x, y});
        visitado[x][y] = true;

        if (x == destinoX && y == destinoY) {
            return true;
        }

        if (encontrarCaminho(x + 1, y) || encontrarCaminho(x - 1, y) ||
            encontrarCaminho(x, y + 1) || encontrarCaminho(x, y - 1)) {
            return true;
        }

        pilha.pop();
        return false;
    }

    private void imprimirCaminho() {
        while (!pilha.isEmpty()) {
            int[] posicao = pilha.pop();
            labirinto[posicao[0]][posicao[1]] = '0'; // Marca o caminho com '0'
        }

        // Destacar o caminho percorrido
        for (int i = 0; i < linhas; i++) {
            for (int j = 0; j < colunas; j++) {
                if (visitado[i][j]) {
                    System.out.print("* ");
                } else {
                    System.out.print(labirinto[i][j] + " ");
                }
            }
            System.out.println();
        }
    }
}
